const cloudinary = require('cloudinary')

cloudName = 'CLOUD_NAME'
cloudID = 'CLOUD_ID'